﻿#pragma strict

function Start () {
Destroy (gameObject, 5);

}

function Update () {

}